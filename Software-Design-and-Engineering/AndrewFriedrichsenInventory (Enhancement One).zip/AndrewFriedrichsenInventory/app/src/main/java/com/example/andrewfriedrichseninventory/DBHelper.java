package com.example.andrewfriedrichseninventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "inventory_app.db";
    private static final int DB_VERSION = 1;

    // ==========================
    // USER TABLE
    // ==========================

    public static final String TABLE_USERS = "users";

    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // ==========================
    // INVENTORY TABLE
    // ==========================

    public static final String TABLE_INVENTORY = "inventory";

    public static final String COL_ITEM_ID = "id";
    public static final String COL_ITEM_NAME = "name";
    public static final String COL_ITEM_QTY = "quantity";
    public static final String COL_ITEM_DESC = "description";

    // ==========================
    // SQL CREATE STATEMENTS
    // ==========================

    private static final String CREATE_USERS_TABLE =
            "CREATE TABLE " + TABLE_USERS + " (" +
                    COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_USERNAME + " TEXT UNIQUE NOT NULL, " +
                    COL_PASSWORD + " TEXT NOT NULL);";

    private static final String CREATE_INVENTORY_TABLE =
            "CREATE TABLE " + TABLE_INVENTORY + " (" +
                    COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_ITEM_NAME + " TEXT NOT NULL, " +
                    COL_ITEM_QTY + " INTEGER NOT NULL, " +
                    COL_ITEM_DESC + " TEXT);";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USERS_TABLE);
        db.execSQL(CREATE_INVENTORY_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion,
                          int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);

        onCreate(db);
    }

    // ==========================================================
    // PASSWORD SECURITY
    // ==========================================================

    private String hashPassword(String password) {

        try {

            MessageDigest md =
                    MessageDigest.getInstance("SHA-256");

            byte[] hash =
                    md.digest(password.getBytes());

            StringBuilder builder =
                    new StringBuilder();

            for (byte b : hash) {
                builder.append(
                        String.format("%02x", b));
            }

            return builder.toString();

        } catch (NoSuchAlgorithmException e) {

            return password;
        }
    }

    // ==========================================================
    // USER METHODS
    // ==========================================================

    public boolean registerUser(String username,
                                String password) {

        if (username == null ||
                username.trim().isEmpty()) {

            return false;
        }

        if (password == null ||
                password.trim().isEmpty()) {

            return false;
        }

        SQLiteDatabase db =
                getWritableDatabase();

        ContentValues values =
                new ContentValues();

        values.put(COL_USERNAME, username);
        values.put(
                COL_PASSWORD,
                hashPassword(password));

        long result =
                db.insert(TABLE_USERS,
                        null,
                        values);

        return result != -1;
    }

    public boolean validateUser(String username,
                                String password) {

        String hashedPassword =
                hashPassword(password);

        SQLiteDatabase db =
                getReadableDatabase();

        String query =
                "SELECT * FROM " + TABLE_USERS +
                        " WHERE " + COL_USERNAME +
                        "=? AND " +
                        COL_PASSWORD + "=?";

        Cursor cursor =
                db.rawQuery(
                        query,
                        new String[]{
                                username,
                                hashedPassword
                        });

        boolean valid =
                cursor.getCount() > 0;

        cursor.close();

        return valid;
    }

    // ==========================================================
    // INVENTORY CRUD METHODS
    // ==========================================================

    public long addItem(String name,
                        int quantity,
                        String description) {

        if (name == null ||
                name.trim().isEmpty()) {

            return -1;
        }

        if (quantity < 0) {

            return -1;
        }

        SQLiteDatabase db =
                getWritableDatabase();

        ContentValues values =
                new ContentValues();

        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_QTY, quantity);
        values.put(COL_ITEM_DESC, description);

        return db.insert(
                TABLE_INVENTORY,
                null,
                values);
    }

    public Cursor getAllItems() {

        SQLiteDatabase db =
                getReadableDatabase();

        return db.query(
                TABLE_INVENTORY,
                null,
                null,
                null,
                null,
                null,
                COL_ITEM_NAME + " ASC"
        );
    }

    public int updateItem(long id,
                          String name,
                          int quantity,
                          String description) {

        SQLiteDatabase db =
                getWritableDatabase();

        ContentValues values =
                new ContentValues();

        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_QTY, quantity);
        values.put(COL_ITEM_DESC, description);

        return db.update(
                TABLE_INVENTORY,
                values,
                COL_ITEM_ID + "=?",
                new String[]{
                        String.valueOf(id)
                });
    }

    public int deleteItem(long id) {

        SQLiteDatabase db =
                getWritableDatabase();

        return db.delete(
                TABLE_INVENTORY,
                COL_ITEM_ID + "=?",
                new String[]{
                        String.valueOf(id)
                });
    }
}