package com.example.andrewfriedrichseninventory;

import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class InventoryActivity extends AppCompatActivity {

    private EditText etNewItemName;
    private EditText etNewItemQty;
    private Button btnAddItem;
    private ListView lvInventory;

    private DBHelper dbHelper;
    private SimpleCursorAdapter adapter;
    private Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        initializeViews();
        initializeDatabase();
        setupList();
        setupListeners();
    }

    private void initializeViews() {
        etNewItemName = findViewById(R.id.etNewItemName);
        etNewItemQty = findViewById(R.id.etNewItemQty);
        btnAddItem = findViewById(R.id.btnAddItem);
        lvInventory = findViewById(R.id.lvInventory);
    }

    private void initializeDatabase() {
        dbHelper = new DBHelper(this);
    }

    private void setupListeners() {

        btnAddItem.setOnClickListener(v -> addItem());

        lvInventory.setOnItemLongClickListener((parent, view, position, id) -> {
            deleteInventoryItem(id);
            return true;
        });

        lvInventory.setOnItemClickListener((parent, view, position, id) -> {
            updateInventoryQuantity(position, id);
        });
    }

    private void setupList() {

        cursor = dbHelper.getAllItems();

        String[] from = {
                DBHelper.COL_ITEM_NAME,
                DBHelper.COL_ITEM_QTY
        };

        int[] to = {
                android.R.id.text1,
                android.R.id.text2
        };

        adapter = new SimpleCursorAdapter(
                this,
                android.R.layout.simple_list_item_2,
                cursor,
                from,
                to,
                0
        );

        lvInventory.setAdapter(adapter);
    }

    private void refreshList() {

        Cursor newCursor = dbHelper.getAllItems();

        adapter.changeCursor(newCursor);

        if (cursor != null) {
            cursor.close();
        }

        cursor = newCursor;
    }

    private void addItem() {

        String name = etNewItemName.getText().toString().trim();
        String qtyStr = etNewItemQty.getText().toString().trim();

        if (!validateInput(name, qtyStr)) {
            return;
        }

        try {

            int qty = Integer.parseInt(qtyStr);

            if (qty < 0) {
                showMessage("Quantity must be zero or greater");
                return;
            }

            dbHelper.addItem(name, qty, "");

            refreshList();
            clearInputFields();

            showMessage("Item added");

        } catch (NumberFormatException e) {

            showMessage("Please enter a valid quantity");
        }
    }

    private void updateInventoryQuantity(int position, long id) {

        Cursor c = (Cursor) adapter.getItem(position);

        String name = c.getString(
                c.getColumnIndexOrThrow(DBHelper.COL_ITEM_NAME));

        int qty = c.getInt(
                c.getColumnIndexOrThrow(DBHelper.COL_ITEM_QTY));

        String desc = c.getString(
                c.getColumnIndexOrThrow(DBHelper.COL_ITEM_DESC));

        dbHelper.updateItem(id, name, qty + 1, desc);

        refreshList();

        showMessage("Quantity updated");
    }

    private void deleteInventoryItem(long id) {

        dbHelper.deleteItem(id);

        refreshList();

        showMessage("Item deleted");
    }

    private boolean validateInput(String name, String qtyStr) {

        if (TextUtils.isEmpty(name) ||
                TextUtils.isEmpty(qtyStr)) {

            showMessage("Enter item name and quantity");
            return false;
        }

        return true;
    }

    private void clearInputFields() {

        etNewItemName.setText("");
        etNewItemQty.setText("");
    }
    private void showMessage(String message) {
        Toast.makeText(
                this,
                message,
                Toast.LENGTH_SHORT
        ).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (cursor != null) {
            cursor.close();
        }
    }
}
